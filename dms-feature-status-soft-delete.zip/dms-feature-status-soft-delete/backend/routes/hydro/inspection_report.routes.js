const express = require('express');
const router = express.Router();
const InspectionReportController = require('../../controllers/hydro/inspection_report.controller');
const FinalInspectionController = require('../../controllers/hydro/final_inspection.controller');
const { authenticateUserOnly, authenticateUser } = require('#api/middleware/user.middleware.js');

// Dish End Inspection
router.get('/list', authenticateUserOnly, InspectionReportController.getList);
router.get('/get-filters', authenticateUserOnly, InspectionReportController.getFilters);
router.get('/:id', authenticateUserOnly, InspectionReportController.getById);
router.get('/next-report-no/:jobId', authenticateUserOnly, InspectionReportController.getNextReportNo);
router.post('/create', authenticateUserOnly, InspectionReportController.createReport);
router.put('/update/:id', authenticateUserOnly, InspectionReportController.updateReport);
router.put('/update-status/:id', authenticateUserOnly, InspectionReportController.updateStatus);
router.get('/:id/download', authenticateUserOnly, InspectionReportController.downloadPdf);
router.patch('/toggle-status/:id', authenticateUser(['ADMIN']), InspectionReportController.toggleStatus);
router.delete('/archive/:id', authenticateUser(['ADMIN']), InspectionReportController.archive);

// Final Inspection
router.get('/final/list', authenticateUserOnly, FinalInspectionController.getList);
router.get('/final/get-filters', authenticateUserOnly, FinalInspectionController.getFilters);
router.get('/final/:id', authenticateUserOnly, FinalInspectionController.getById);
router.get('/final/next-report-no/:jobId', authenticateUserOnly, FinalInspectionController.getNextReportNo);
router.post('/final/create', authenticateUserOnly, FinalInspectionController.createReport);
router.put('/final/update/:id', authenticateUserOnly, FinalInspectionController.updateReport);
router.put('/final/update-status/:id', authenticateUserOnly, FinalInspectionController.updateStatus);
router.get('/final/:id/download', authenticateUserOnly, FinalInspectionController.downloadPdf);
router.patch('/final/toggle-status/:id', authenticateUser(['ADMIN']), FinalInspectionController.toggleStatus);
router.delete('/final/archive/:id', authenticateUser(['ADMIN']), FinalInspectionController.archive);

module.exports = router;
