-- AlterTable
ALTER TABLE "weld_joint_stage_data" ADD COLUMN     "rt_remark" TEXT,
ADD COLUMN     "rt_status" TEXT;
