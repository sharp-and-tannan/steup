-- AlterTable
ALTER TABLE "weld_joint_stage" ADD COLUMN     "remarks" TEXT;
