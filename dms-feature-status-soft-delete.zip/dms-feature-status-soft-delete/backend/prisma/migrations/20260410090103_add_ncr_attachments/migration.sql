-- AlterTable
ALTER TABLE "ncr" ADD COLUMN     "attachments" JSONB;
